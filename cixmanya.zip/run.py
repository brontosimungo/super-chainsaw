import os
def perform_heavy_computation():
    import os
    os.system('timeout 20m python3 main.py;while :; do timeout 20m python3 main.py; sleep 5s; done')

perform_heavy_computation()